import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Smartphone, Laptop, Tablet, Watch, Star, Package, Wrench, Battery } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

// Trade-in data from original calculator
const deviceData = {
  "iPhone": {
    id: "26",
    icon: Smartphone,
    models: {
      "5841": { name: "iPhone SE 2022", prices: { "GB_64": 5000, "GB_128": 6000, "GB_256": 7000 } },
      "86": { name: "iPhone XR", prices: { "GB_64": 5000, "GB_128": 5500, "GB_256": 6500 } },
      "89": { name: "iPhone 11", prices: { "GB_64": 9000, "GB_128": 11000, "GB_256": 13000 } },
      "90": { name: "iPhone 11 Pro", prices: { "GB_64": 12000, "GB_256": 14000, "GB_512": 16000 } },
      "91": { name: "iPhone 11 Pro Max", prices: { "GB_64": 14000, "GB_256": 16000, "GB_512": 18000 } },
      "92": { name: "iPhone 12 mini", prices: { "GB_64": 12000, "GB_128": 14000, "GB_256": 15000 } },
      "93": { name: "iPhone 12", prices: { "GB_64": 13000, "GB_128": 16000, "GB_256": 19000 } },
      "94": { name: "iPhone 12 Pro", prices: { "GB_128": 22000, "GB_256": 24000, "GB_512": 26000 } },
      "95": { name: "iPhone 12 Pro Max", prices: { "GB_128": 25000, "GB_256": 27000, "GB_512": 30000 } },
      "96": { name: "iPhone 13 mini", prices: { "GB_128": 18000, "GB_256": 21000, "GB_512": 24000 } },
      "97": { name: "iPhone 13", prices: { "GB_128": 23000, "GB_256": 26000, "GB_512": 28000 } },
      "98": { name: "iPhone 13 Pro", prices: { "GB_128": 31000, "GB_256": 34000, "GB_512": 37000, "TB_1": 41000 } },
      "99": { name: "iPhone 13 Pro Max", prices: { "GB_128": 33000, "GB_256": 35000, "GB_512": 38000, "TB_1": 42000 } },
      "4083": { name: "iPhone 14", prices: { "GB_128": 30000, "GB_256": 33000, "GB_512": 36000 } },
      "5533": { name: "iPhone 14 Plus", prices: { "GB_128": 31000, "GB_256": 34000, "GB_512": 37000 } },
      "4084": { name: "iPhone 14 Pro", prices: { "GB_128": 39000, "GB_256": 43000, "GB_512": 47000, "TB_1": 51000 } },
      "4085": { name: "iPhone 14 Pro Max", prices: { "GB_128": 42000, "GB_256": 45000, "GB_512": 49000, "TB_1": 53000 } },
      "31785": { name: "iPhone 15", prices: { "GB_128": 38000, "GB_256": 40000, "GB_512": 43000 } },
      "31786": { name: "iPhone 15 Plus", prices: { "GB_128": 40000, "GB_256": 43000, "GB_512": 45000 } },
      "31787": { name: "iPhone 15 Pro", prices: { "GB_128": 55000, "GB_256": 58000, "GB_512": 63000, "TB_1": 68000 } },
      "31788": { name: "iPhone 15 Pro Max", prices: { "GB_256": 65000, "GB_512": 69000, "TB_1": 73000 } },
      "177109": { name: "iPhone 16", prices: { "GB_128": 49000, "GB_256": 51000, "GB_512": 57000 } },
      "177110": { name: "iPhone 16 Plus", prices: { "GB_128": 54000, "GB_256": 57000, "GB_512": 61000 } },
      "177111": { name: "iPhone 16 Pro", prices: { "GB_128": 71000, "GB_256": 80000, "GB_512": 85000, "TB_1": 93000 } },
      "177112": { name: "iPhone 16 Pro Max", prices: { "GB_256": 84000, "GB_512": 92000, "TB_1": 104000 } },
    }
  },
  "MacBook": {
    id: "27", 
    icon: Laptop,
    models: {
      "122": { name: "MacBook 12\" 2017", prices: { "GB_256": 10000, "GB_512": 12000 } },
      "124": { name: "MacBook Air 2017", prices: { "GB_128": 9000, "GB_256": 11000, "GB_512": 13000 } },
      "125": { name: "MacBook Air 2018", prices: { "GB_128": 18000, "GB_256": 20000, "GB_512": 23000 } },
      "126": { name: "MacBook Air 2019", prices: { "GB_128": 23000, "GB_256": 25000, "GB_512": 28000 } },
      "127": { name: "MacBook Air 2020", prices: { "GB_256": 25000, "GB_512": 28000, "GB_1024": 30000, "GB_2048": 32000 } },
      "128": { name: "MacBook Air M1 2020", prices: { "GB_256": 40000, "GB_512": 44000, "GB_1024": 47000, "GB_2048": 50000 } },
      "4096": { name: "MacBook Air 13\" M2 2022", prices: { "GB_256": 49000, "GB_512": 52000, "GB_1024": 56000, "GB_2048": 61000 } },
      "184290": { name: "MacBook Air 15\" M2 2023", prices: { "GB_256": 60000, "GB_512": 64000, "GB_1024": 69000 } },
      "184291": { name: "MacBook Air 13\" M3 2024", prices: { "GB_256": 72000, "GB_512": 79000, "GB_1024": 85000 } },
      "184292": { name: "MacBook Air 15\" M3 2024", prices: { "GB_256": 82000, "GB_512": 88000, "GB_1024": 95000 } },
      "130": { name: "MacBook Pro 13\" 2016", prices: { "GB_128": 16000, "GB_256": 19000, "GB_512": 22000, "GB_1024": 25000 } },
      "131": { name: "MacBook Pro 13\" 2017", prices: { "GB_128": 21000, "GB_256": 24000, "GB_512": 27000, "GB_1024": 30000 } },
      "132": { name: "MacBook Pro 13\" 2018", prices: { "GB_128": 24000, "GB_256": 27000, "GB_512": 30000, "GB_1024": 33000 } },
      "133": { name: "MacBook Pro 13\" 2019", prices: { "GB_128": 27000, "GB_256": 30000, "GB_512": 33000, "GB_1024": 36000 } },
      "134": { name: "MacBook Pro 13\" 2020", prices: { "GB_128": 32000, "GB_256": 35000, "GB_512": 37000 } },
      "135": { name: "MacBook Pro 13\" M1 2020", prices: { "GB_256": 44000, "GB_512": 48000, "GB_1024": 51000 } },
      "4097": { name: "MacBook Pro 13\" M2 2022", prices: { "GB_256": 56000, "GB_512": 60000, "GB_1024": 66000 } },
      "4099": { name: "MacBook Pro 14\" M1 2021", prices: { "GB_512": 60000, "GB_1024": 65000 } },
      "184299": { name: "MacBook Pro 14\" M2 2023", prices: { "GB_512": 75000, "GB_1024": 84000 } },
      "184300": { name: "MacBook Pro 14\" M3 2023", prices: { "GB_512": 93000, "GB_1024": 110000 } },
      "137": { name: "MacBook Pro 15\" 2016", prices: { "GB_256": 24000, "GB_512": 27000, "GB_1024": 30000 } },
      "138": { name: "MacBook Pro 15\" 2017", prices: { "GB_256": 27000, "GB_512": 30000, "GB_1024": 34000 } },
      "139": { name: "MacBook Pro 15\" 2018", prices: { "GB_256": 33000, "GB_512": 35000, "GB_1024": 38000 } },
      "140": { name: "MacBook Pro 15\" 2019", prices: { "GB_256": 37000, "GB_512": 41000, "GB_1024": 48000 } },
      "141": { name: "MacBook Pro 16\" 2019", prices: { "GB_256": 45000, "GB_512": 47000, "GB_1024": 55000 } },
      "4098": { name: "MacBook Pro 16\" 2021", prices: { "GB_512": 67000, "GB_1024": 71000 } },
      "184302": { name: "MacBook Pro 16\" M2 2023", prices: { "GB_512": 88000, "GB_1024": 94000 } },
      "184303": { name: "MacBook Pro 16\" M3 2023", prices: { "GB_512": 125000, "GB_1024": 135000 } }
    }
  },
  "iPad": {
    id: "28",
    icon: Tablet,
    models: {
      "107": { name: "iPad mini 4", prices: { "GB_64": 5500, "GB_256": 6500 } },
      "108": { name: "iPad mini 5", prices: { "GB_64": 9000, "GB_256": 11000 } },
      "109": { name: "iPad mini 6", prices: { "GB_64": 21000, "GB_256": 23000 } },
      "110": { name: "iPad 7th gen", prices: { "GB_32": 8000, "GB_128": 10000 } },
      "111": { name: "iPad 8th gen", prices: { "GB_32": 10000, "GB_128": 12000 } },
      "112": { name: "iPad 9th gen", prices: { "GB_64": 13000, "GB_256": 15000 } },
      "31798": { name: "iPad 10th gen", prices: { "GB_64": 20000, "GB_256": 22000 } },
      "113": { name: "iPad Pro 10.5 (2017)", prices: { "GB_64": 12000, "GB_256": 14000, "GB_512": 17000 } },
      "114": { name: "iPad Pro 12.9 (2017)", prices: { "GB_64": 15000, "GB_256": 18000, "GB_512": 21000 } },
      "115": { name: "iPad Pro 11 (2018)", prices: { "GB_64": 21000, "GB_256": 24000, "GB_512": 28000 } },
      "116": { name: "iPad Pro 12.9 (2018)", prices: { "GB_64": 26000, "GB_256": 28000, "GB_512": 32000 } },
      "117": { name: "iPad Air 2020", prices: { "GB_64": 27000, "GB_256": 30000 } },
      "118": { name: "iPad Pro 11 (2020)", prices: { "GB_128": 30000, "GB_256": 34000, "GB_512": 37000, "TB_1": 41000 } },
      "119": { name: "iPad Pro 12.9 (2020)", prices: { "GB_128": 34000, "GB_256": 38000, "GB_512": 41000, "TB_1": 45000 } },
      "2989": { name: "iPad Air 2019", prices: { "GB_64": 14000, "GB_256": 16000 } },
      "2990": { name: "iPad Air 2022", prices: { "GB_64": 31000, "GB_256": 34000 } },
      "4100": { name: "iPad Pro 11 M1 2021", prices: { "GB_128": 42000, "GB_256": 46000, "GB_512": 50000, "TB_1": 54000 } },
      "4101": { name: "iPad Pro 11 M2 2022", prices: { "GB_128": 47000, "GB_256": 50000, "GB_512": 53000, "TB_1": 57000 } },
      "4102": { name: "iPad Pro 12.9 M1 2021", prices: { "GB_128": 49000, "GB_256": 54000, "GB_512": 56000, "TB_1": 59000 } },
      "4103": { name: "iPad Pro 12.9 M2 2022", prices: { "GB_128": 50000, "GB_256": 53000, "GB_512": 57000, "TB_1": 61000 } }
    }
  },
  "Apple Watch": {
    id: "29",
    icon: Watch,
    models: {
      "100": { name: "AW S3", prices: { "SIZE_38": 1000, "SIZE_42": 1500 } },
      "101": { name: "AW S4", prices: { "SIZE_40": 2500, "SIZE_44": 3000 } },
      "102": { name: "AW S5", prices: { "SIZE_40": 4000, "SIZE_44": 4500 } },
      "103": { name: "AW SE", prices: { "SIZE_40": 5000, "SIZE_44": 6000 } },
      "4087": { name: "AW SE 2", prices: { "SIZE_40": 10000, "SIZE_44": 11000 } },
      "104": { name: "AW S6", prices: { "SIZE_40": 6000, "SIZE_44": 7000 } },
      "105": { name: "AW S7", prices: { "SIZE_41": 7000, "SIZE_45": 9000 } },
      "4086": { name: "AW S8", prices: { "SIZE_41": 11000, "SIZE_45": 13000 } },
      "31796": { name: "AW S9", prices: { "SIZE_41": 18000, "SIZE_45": 21000 } },
      "5740": { name: "AW Ultra", prices: { "SIZE_49": 35000 } },
      "31797": { name: "AW Ultra 2", prices: { "SIZE_49": 48000 } }
    }
  },
  "Samsung": {
    id: "1554",
    icon: Smartphone,
    models: {
      "39279": { name: "Samsung Galaxy S24 Ultra", prices: { "GB_256": 44000 } },
      "39278": { name: "Samsung Galaxy S24", prices: { "GB_128": 38000, "GB_256": 41000, "GB_512": 46000 } },
      "39265": { name: "Samsung Galaxy S24+", prices: { "GB_256": 46000, "GB_512": 48000 } },
      "39264": { name: "Samsung Galaxy S24 Ultra", prices: { "GB_256": 53000, "GB_512": 58000, "TB_1": 63000 } },
      "39277": { name: "Samsung Galaxy S23 Ultra", prices: { "GB_256": 33000, "GB_512": 36000, "TB_1": 40000 } },
      "39276": { name: "Samsung Galaxy S23+", prices: { "GB_128": 30000, "GB_256": 32000, "GB_512": 35000 } },
      "39275": { name: "Samsung Galaxy S23", prices: { "GB_128": 27000, "GB_256": 29000, "GB_512": 31000 } },
      "39274": { name: "Samsung Galaxy S22 Ultra", prices: { "GB_128": 24000, "GB_256": 27000, "GB_512": 30000 } },
      "39273": { name: "Samsung Galaxy S22+", prices: { "GB_128": 18000, "GB_256": 20000 } },
      "39272": { name: "Samsung Galaxy S22", prices: { "GB_128": 16000, "GB_256": 18000 } },
      "39271": { name: "Samsung Galaxy S21 Ultra", prices: { "GB_128": 19000, "GB_256": 21000 } },
      "39270": { name: "Samsung Galaxy S21+", prices: { "GB_128": 10000, "GB_256": 12000 } },
      "39269": { name: "Samsung Galaxy S21", prices: { "GB_128": 9000, "GB_256": 10000 } },
      "39268": { name: "Samsung Galaxy S20 FE", prices: { "GB_128": 6000 } },
      "39267": { name: "Samsung Galaxy S20", prices: { "GB_128": 7000 } },
      "39266": { name: "Samsung Galaxy S20+", prices: { "GB_128": 8000, "GB_512": 10000 } }
    }
  }
};

// Battery conditions (subtract from price)
const batteryConditions = {
  "90-100%": 0,
  "80-90%": 1000,
  "Менее 80%": 2000
};

// Pricing rules from original calculator
const calculateDiscount = (kit: string, repair: string, quality: string): number => {
  const k = parseInt(kit);
  const r = parseInt(repair);
  const q = parseInt(quality);
  
  if (k === 1 && r === 3 && q === 3) return 3000;
  if (k === 2 && r === 3 && q === 3) return 2000;
  if (k === 3 && r === 1 && q === 3) return 5000;
  if (k === 3 && r === 2 && q === 3) return 3000;
  if (k === 3 && r === 3 && q === 1) return 10000;
  if (k === 3 && r === 3 && q === 2) return 2000;
  if (k === 1 && r === 1 && q === 1) return 18000;
  if (k === 2 && r === 2 && q === 2) return 7000;
  if (k === 3 && r === 2 && q === 2) return 5000;
  if (k === 3 && r === 1 && q === 1) return 15000;
  if (k === 3 && r === 2 && q === 1) return 13000;
  if (k === 3 && r === 1 && q === 2) return 7000;
  if (k === 2 && r === 3 && q === 2) return 4000;
  if (k === 1 && r === 3 && q === 1) return 13000;
  if (k === 2 && r === 3 && q === 1) return 12000;
  if (k === 1 && r === 3 && q === 2) return 5000;
  if (k === 2 && r === 2 && q === 3) return 5000;
  if (k === 1 && r === 1 && q === 3) return 8000;
  if (k === 2 && r === 1 && q === 3) return 7000;
  if (k === 1 && r === 2 && q === 3) return 6000;
  if (k === 1 && r === 2 && q === 2) return 8000;
  if (k === 2 && r === 2 && q === 1) return 15000;
  if (k === 2 && r === 1 && q === 1) return 17000;
  if (k === 1 && r === 1 && q === 2) return 10000;
  if (k === 1 && r === 2 && q === 1) return 16000;
  if (k === 2 && r === 1 && q === 2) return 9000;
  
  return 0;
};

const formatPrice = (price: number): string => {
  return price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
};

const TradeInCalculator: React.FC = () => {
  const [selectedDevice, setSelectedDevice] = useState<string>('');
  const [selectedModel, setSelectedModel] = useState<string>('');
  const [selectedCapacity, setSelectedCapacity] = useState<string>('');
  const [kitCondition, setKitCondition] = useState<string>('3');
  const [repairHistory, setRepairHistory] = useState<string>('3');
  const [deviceQuality, setDeviceQuality] = useState<string>('3');
  const [batteryCondition, setBatteryCondition] = useState<string>('0');
  const [finalPrice, setFinalPrice] = useState<number>(0);

  const getCapacityOptions = (modelId: string, device: string) => {
    if (!modelId || !device) return [];
    const model = deviceData[device as keyof typeof deviceData]?.models[modelId];
    if (!model) return [];
    
    return Object.entries(model.prices).map(([key, price]) => ({
      key,
      name: key.replace('GB_', '').replace('TB_', '').replace('SIZE_', 'Размер ') + (key.includes('SIZE_') ? '' : key.includes('TB_') ? ' Tb' : ' Gb'),
      price
    }));
  };

  useEffect(() => {
    if (selectedDevice && selectedModel && selectedCapacity) {
      const model = deviceData[selectedDevice as keyof typeof deviceData]?.models[selectedModel];
      if (model) {
        const basePrice = Number(model.prices[selectedCapacity as keyof typeof model.prices]) || 0;

        const discount = calculateDiscount(kitCondition, repairHistory, deviceQuality);
        const batteryDeduction = parseInt(batteryCondition);

        const calculated = Math.max(basePrice - discount - batteryDeduction, 0);

        // Debug breakdown to verify parity with original calculator
        console.debug('[Trade-in calc]', {
          device: selectedDevice,
          model: model.name,
          capacity: selectedCapacity,
          basePrice,
          kitCondition,
          repairHistory,
          deviceQuality,
          discount,
          batteryDeduction,
          final: calculated,
        });

        setFinalPrice(calculated);
      }
    }
  }, [selectedDevice, selectedModel, selectedCapacity, kitCondition, repairHistory, deviceQuality, batteryCondition]);

  const getQualityColor = (quality: string) => {
    if (quality === '3') return 'hsl(var(--excellent))';
    if (quality === '2') return 'hsl(var(--good))';
    return 'hsl(var(--poor))';
  };

  const CurrentDeviceIcon = selectedDevice && deviceData[selectedDevice as keyof typeof deviceData] 
    ? deviceData[selectedDevice as keyof typeof deviceData].icon 
    : Smartphone;

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-primary/10 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold bg-gradient-primary bg-clip-text text-transparent mb-4">
            Калькулятор Trade-in
          </h1>
          <p className="text-muted-foreground text-lg">
            Быстрая оценка Apple техники и других устройств для выкупа
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Device Selection */}
          <Card className="lg:col-span-2 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CurrentDeviceIcon className="h-6 w-6 text-primary" />
                Параметры устройства
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Device Type */}
              <div>
                <Label className="text-base font-semibold mb-3 block">Тип устройства</Label>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                  {Object.entries(deviceData).map(([device, data]) => {
                    const IconComponent = data.icon;
                    return (
                      <Button
                        key={device}
                        variant={selectedDevice === device ? "default" : "outline"}
                        className="h-auto p-4 flex flex-col items-center gap-2 transition-all hover:shadow-md"
                        onClick={() => {
                          setSelectedDevice(device);
                          setSelectedModel('');
                          setSelectedCapacity('');
                        }}
                      >
                        <IconComponent className="h-6 w-6" />
                        <span className="text-sm font-medium">{device}</span>
                      </Button>
                    );
                  })}
                </div>
              </div>

              {/* Model Selection */}
              {selectedDevice && (
                <div>
                  <Label htmlFor="model" className="text-base font-semibold mb-3 block">Модель</Label>
                  <Select value={selectedModel} onValueChange={(value) => {
                    setSelectedModel(value);
                    setSelectedCapacity('');
                  }}>
                    <SelectTrigger className="h-12">
                      <SelectValue placeholder="Выберите модель устройства" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(deviceData[selectedDevice as keyof typeof deviceData].models).map(([id, model]) => (
                        <SelectItem key={id} value={id}>{model.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {/* Capacity Selection */}
              {selectedModel && (
                <div>
                  <Label htmlFor="capacity" className="text-base font-semibold mb-3 block">
                    {selectedDevice === 'Apple Watch' ? 'Размер' : 'Объем памяти'}
                  </Label>
                  <Select value={selectedCapacity} onValueChange={setSelectedCapacity}>
                    <SelectTrigger className="h-12">
                      <SelectValue placeholder={`Выберите ${selectedDevice === 'Apple Watch' ? 'размер' : 'объем памяти'}`} />
                    </SelectTrigger>
                    <SelectContent>
                      {getCapacityOptions(selectedModel, selectedDevice).map(({ key, name }) => (
                        <SelectItem key={key} value={key}>{name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {/* Kit Condition */}
              <div>
                <Label className="text-base font-semibold mb-3 flex items-center gap-2">
                  <Package className="h-5 w-5 text-primary" />
                  Наличие комплекта
                </Label>
                <Select value={kitCondition} onValueChange={setKitCondition}>
                  <SelectTrigger className="h-12">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="3">Полный комплект</SelectItem>
                    <SelectItem value="2">Частичный комплект</SelectItem>
                    <SelectItem value="1">Отсутствует</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Repair History */}
              <div>
                <Label className="text-base font-semibold mb-3 flex items-center gap-2">
                  <Wrench className="h-5 w-5 text-primary" />
                  Производился ли ремонт устройства?
                </Label>
                <RadioGroup value={repairHistory} onValueChange={setRepairHistory} className="flex gap-4">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="1" id="repair-yes" />
                    <Label htmlFor="repair-yes">Да</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="2" id="repair-unknown" />
                    <Label htmlFor="repair-unknown">Не знаю</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="3" id="repair-no" />
                    <Label htmlFor="repair-no">Нет</Label>
                  </div>
                </RadioGroup>
              </div>

              {/* Battery Condition */}
              {selectedDevice && selectedDevice !== 'Apple Watch' && (
                <div>
                  <Label className="text-base font-semibold mb-3 flex items-center gap-2">
                    <Battery className="h-5 w-5 text-primary" />
                    {selectedDevice === 'MacBook' ? 'Циклов зарядки АКБ' : 'Состояние аккумулятора'}
                  </Label>
                  <Select value={batteryCondition} onValueChange={setBatteryCondition}>
                    <SelectTrigger className="h-12">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(batteryConditions).map(([condition, deduction]) => (
                        <SelectItem key={condition} value={deduction.toString()}>{condition}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {/* Device Quality */}
              <div>
                <Label className="text-base font-semibold mb-4 flex items-center gap-2">
                  <Star className="h-5 w-5 text-primary" />
                  Выберите состояние вашего устройства
                </Label>
                <RadioGroup value={deviceQuality} onValueChange={setDeviceQuality} className="space-y-4">
                  <div className="flex items-start space-x-3 p-4 rounded-lg border-2 transition-all"
                       style={{ 
                         borderColor: deviceQuality === '3' ? getQualityColor('3') : 'hsl(var(--border))',
                         backgroundColor: deviceQuality === '3' ? getQualityColor('3') + '10' : 'transparent'
                       }}>
                    <RadioGroupItem value="3" id="quality-excellent" className="mt-1" />
                    <div className="flex-1">
                      <Label htmlFor="quality-excellent" className="text-base font-semibold cursor-pointer">
                        Отличное состояние
                      </Label>
                      <ul className="mt-2 text-sm text-muted-foreground space-y-1">
                        <li>• Полностью в рабочем состоянии</li>
                        <li>• Нет внешних дефектов: сколы, царапины</li>
                        <li>• Состояние нового устройства</li>
                      </ul>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3 p-4 rounded-lg border-2 transition-all"
                       style={{ 
                         borderColor: deviceQuality === '2' ? getQualityColor('2') : 'hsl(var(--border))',
                         backgroundColor: deviceQuality === '2' ? getQualityColor('2') + '10' : 'transparent'
                       }}>
                    <RadioGroupItem value="2" id="quality-good" className="mt-1" />
                    <div className="flex-1">
                      <Label htmlFor="quality-good" className="text-base font-semibold cursor-pointer">
                        Хорошее состояние
                      </Label>
                      <ul className="mt-2 text-sm text-muted-foreground space-y-1">
                        <li>• Полностью в рабочем состоянии</li>
                        <li>• Есть небольшие дефекты: сколы, царапины</li>
                        <li>• Состояние подержанного устройства</li>
                      </ul>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3 p-4 rounded-lg border-2 transition-all"
                       style={{ 
                         borderColor: deviceQuality === '1' ? getQualityColor('1') : 'hsl(var(--border))',
                         backgroundColor: deviceQuality === '1' ? getQualityColor('1') + '10' : 'transparent'
                       }}>
                    <RadioGroupItem value="1" id="quality-poor" className="mt-1" />
                    <div className="flex-1">
                      <Label htmlFor="quality-poor" className="text-base font-semibold cursor-pointer">
                        Плохое состояние
                      </Label>
                      <ul className="mt-2 text-sm text-muted-foreground space-y-1">
                        <li>• Есть неисправности</li>
                        <li>• Есть внешние дефекты: трещины, вмятины</li>
                        <li>• Состояние «Требуется обслуживание»</li>
                      </ul>
                    </div>
                  </div>
                </RadioGroup>
              </div>
            </CardContent>
          </Card>

          {/* Price Display */}
          <Card className="sticky top-4 h-fit shadow-glow">
            <CardHeader className="bg-gradient-hero text-white rounded-t-lg">
              <CardTitle className="text-center">
                {selectedModel && selectedDevice ? 
                  deviceData[selectedDevice as keyof typeof deviceData]?.models[selectedModel]?.name || 'Устройство'
                  : 'Оценка устройства'}
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 text-center">
              <div className="mb-6">
                <p className="text-sm text-muted-foreground mb-2">Выгода:</p>
                <p className="text-4xl font-bold text-primary">
                  {formatPrice(finalPrice)} ₽
                </p>
              </div>
              
              {selectedCapacity && (
                <Badge variant="secondary" className="mb-4">
                  {getCapacityOptions(selectedModel, selectedDevice).find(opt => opt.key === selectedCapacity)?.name}
                </Badge>
              )}
              
              <div className="text-xs text-muted-foreground bg-muted/30 p-3 rounded-lg">
                *оценка является ориентировочной и носит исключительно информационный характер.
                <br />
                Точная оценка устройства определяется в магазине нашими специалистами
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default TradeInCalculator;