import TradeInCalculator from '@/components/TradeInCalculator';

const Index = () => {
  return <TradeInCalculator />;
};

export default Index;
